 //* Some of this code isn't mine
console.log("js launched");

window.AudioContext = window.AudioContext || window.webkitAudioContext;

let context;

function playSound(arr) {
  let buf = new Float32Array(arr.length);
  for (let i = 0; i < arr.length; i++) buf[i] = arr[i];
  let buffer = context.createBuffer(1, buf.length, context.sampleRate);
  buffer.copyToChannel(buf, 0);
  let source = context.createBufferSource();
  source.buffer = buffer;
  source.connect(context.destination);
  source.start(0);
}

function sineWaveAt(sampleNumber, tone) {
  let sampleFreq = context.sampleRate / tone;
  return Math.sin(sampleNumber / (sampleFreq / (Math.PI * 2)));
}

function play(vst) {
  //* Takes format as an array in the form volume (0 - 1), time (seconds), tone (hz)
  let arr = [];

  for (let i = 0; i < context.sampleRate * vst[1]; i++) {
    arr[i] = sineWaveAt(i, vst[2]) * vst[0];
  }
  playSound(arr);
}

//* All of the code below is mine:

const base_tone = 440*Math.pow(2, -9/12);  //* The tone of the base note in hz
console.log("base tone = " + base_tone);
const lowest_speed = 2;       //* The speed when speed is set to 0
const exponent = 1.027;       //* The rate at which the speed gets exponentially faster
const page = window.location.href.substr(-6, 1); //*The page number, works by obtaining the last character before the .html"
const min_volume_full = 50;   //* The minimum sound value to use the full speaker icon
const min_volume_partial = 1; //* The minimum sound value to use the partial speaker icon
const pow = (base, exponent) => base ** exponent;   //* The power function, replaces Math.pow to work with BigInt
let sound = false;            //* Whether or not sound is currently supposed to be playing
let current_interval;         //* The current periodic command to plays the next note
let context_started = false;  //* Whether or not the audio context has started yet
let term = 0;                 //* The current term of the sequence
let previous_term;            //* What the value of the previous term was
let current_speaker = 2;      //* The current speaker icon displayed, 2 being full, 1 being half & 0 being no sound


function play_next() {
  //* Play the next note
  let p = play([volume_input.value/100, lowest_speed/(Math.pow(exponent, speed_input.value)), frequency()]);
}

function update() {
  //* Update the interval that plays the notes
  console.log("updated");
  clearTimeout(current_interval);
  if(sound) {
    current_interval = setInterval(play_next, 1000*lowest_speed/(Math.pow(exponent, speed_input.value)));
    document.getElementById("play_button").src="images/pause.png";
  } else {
    current_interval = "";
    document.getElementById("play_button").src="images/play.png";
  }
}

function sound_update() {
  //* Update the volume display
  if (volume_input.value>=min_volume_full) {
    document.getElementById("volume_display").src="images/volume_full.png";
    current_speaker = 2;
  } else if (volume_input.value>=min_volume_partial) {
    document.getElementById("volume_display").src="images/volume_partial.png";
    current_speaker = 1;
  } else {
    document.getElementById("volume_display").src="images/volume_none.png";
    current_speaker = 0;
  }
}

function stop_clicked() {
  console.log("stop clicked");
  sound = false;
  term = 0;
  previous_term = null;
  update();
}

function play_clicked() {
  console.log("play clicked");
  
  if (sound) {
    sound = false;
  } else {
    sound = true;
  }
  
  if(!(context_started)) {
    context = new AudioContext();
    context_started = true;
  }
  
  if (sound) {
    play_next();
  }
  update();
}

function convert_to_number(input) {
  //* Convert user input to a BigInt
  input = input.replace(",", "");
  return(BigInt(input));
}

function frequency() {
  //* Calculate the appropriate frequency for the note
  term++;
  let new_term;       //* the next term in the sequence
  
  if (page==1) {
    //*fibonacci
    if (previous_term) {
      new_term = previous_term[0] + previous_term[1];
    } else {
      new_term = BigInt(number_1st.value);
      previous_term = [BigInt(number_2nd.value)];
    }
    previous_term = [new_term, previous_term[0]];
    console.log(previous_term);
  }
  
  if (page==2) {
    //*hailstone
    if (previous_term) {
      new_term = previous_term;
      if (new_term%BigInt(2) == 0) {
        new_term = new_term/BigInt(2);
      } else {
        new_term = new_term*BigInt(3)+BigInt(1);
      }
    } else {
      new_term = BigInt(starting_number.value);
    }
    previous_term = new_term;
  }
  
  if (page==3) {
    //*polynomial
    if (!previous_term) {
      //*on polynomial page, previous term is used to store the polynomial rather than the previous term
      previous_term = terms.value.split(" ").map(convert_to_number);
      console.log(previous_term);
      }
    new_term = BigInt(0);
    for (let i = 0; i < previous_term.length; i++) {
      new_term += previous_term[i] * pow(BigInt(term), BigInt(previous_term.length) - BigInt(i + 1));
      console.log(previous_term.length - i - 1);
    }
    
        
    
  }


  console.log(term + ", " + new_term);
  term_display.textContent = term;
  number_display.textContent = Number(new_term);
  return(base_tone*Math.pow(2, (Number(new_term%BigInt(12)))/12));
}

console.log("JS loaded and everything defined");